var process = function() {
	"use strict";
	return {
		audio: function(audio,time) {
			setInterval (function() {
			bgAudio.play();
		},time)
		},
	Nahuli: function(player,enemy){
		nahuli.play();
		player.kill();
		
		game._paused = true;
        bgAudio.play();
        gameOverTxt.text = "The Game is Over! \nScore: "+score+"\nBest: "+process.getData()+"\nTap to Restart ";
        game.state.start(game.state.current);
     			setTimeout(function(){
        		game._paused = false;
			}, 2000)
        	
        	},
	Makalagpas: function(player,platformTrans){
			score= score + 1;
			makalagpas.play();
    		platformTrans.kill();
            
    		if(process.getData()<=score) {
    			process.saveData(score);
    			bestTxt.text = "Best: "+score;
    		}
    		else {
    			console.log("");
    		}
    		scoreTxt.text = "Score: "+score;
		},
	saveData: function(score) {
			localStorage.setItem("gameData", score);
		},	
		getData: function() {
			return (localStorage.getItem("gameData")== null || localStorage.getItem("gameData") == "")?0:localStorage.getItem("gameData");
		},
	pause: function(){
        	this.game.paused = true;
        	
        	pauseTxt.text = "Game paused.\nTap anywhere to continue.";
        	        
        	this.input.onDown.add(function(){
            pauseTxt.destroy();
            this.game.paused = false;
        	}, this);
   	 	},
    	restart: function(){
    		game.state.start(game.state.current);
		}

}
}();