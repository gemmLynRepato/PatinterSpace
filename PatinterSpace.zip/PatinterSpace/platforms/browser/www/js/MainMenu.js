var Menu = {

    preload : function() {
        game.load.spritesheet('play', 'img/play.png',219,208);
        game.load.image('starfield', 'img/star6.png');
        game.load.image('starfield0', 'img/star3.png');
        game.load.image('starfield1', 'img/star2.png');
        game.load.image('starfield2', 'img/star4.png');
        game.load.image("title","img/title.png");
        game.load.audio("bgMusic","audio/bgMusic.mp3");
    },

    create: function () {
        this.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
     
        title = game.add.sprite(0,100,"title");
        starfield = game.add.tileSprite(0,0,800,600,'starfield');
        starfield0 = game.add.tileSprite(0,0,800,600,'starfield');
        starfield1 = game.add.tileSprite(0,0,800,600,'starfield1');
        starfield2 = game.add.tileSprite(0,0,800,600,'starfield2');
        
        play = this.add.button(120,280, 'play', this.startGame, this, 1,0);
        play.scale.x = 0.6;
        play.scale.y = 0.6;

    	bgAudio = game.add.audio("bgMusic");
    	bgAudio.play();
    },
    update: function() {
        starfield.tilePosition.y += 2;
        starfield0.tilePosition.y += 2;
        starfield1.tilePosition.y += 2;
        starfield2.tilePosition.y += 2;
    },
    startGame: function () {
        this.state.start('Game');
    }
};