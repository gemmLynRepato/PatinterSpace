var Game = {
	preload: function() {
		game.load.image("star1","img/star1.png");
		game.load.image("star2","img/star2.png");
		game.load.image("star3","img/star3.png");
		game.load.image("star4","img/star4.png");
		game.load.image("star5","img/star5.png");
		game.load.image("star6","img/star6.png");
		game.load.image("platform","img/platform.png");
		game.load.image("platform2","img/platform2.png");
		game.load.image("enemy","img/alien.png");
        game.load.image("platformTrans","img/transparent.png");
        
		game.load.spritesheet("char","img/char2.png",112,150);
		game.load.spritesheet("left","img/left.png",219,208);
		game.load.spritesheet("right","img/right.png",219,208);
		game.load.spritesheet("up","img/up.png",219,208);
		game.load.spritesheet("pause","img/pause.png",219,208);
		game.load.spritesheet("restart","img/restart.png",219,208);
		game.load.audio("bgMusic",['audio/bgMusic.mp3,audio/bgMusic.ogg,audio/bgMusic.m4a']);
        game.load.audio("iMadeIt",['audio/iMadeIt.mp3,audio/iMadeIt.ogg,audio/iMadeIt.m4a']);
        game.load.audio("huliKa",['audio/huliKa.mp3,audio/huliKa.ogg,audio/huliKa.m4a']);
	},
	create: function() {
        this.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
		game.physics.startSystem(Phaser.Physics.ARCADE);
		game.world.setBounds(0,0,0,bounds);
		game.stage.backgroundColor ="#000";

        player = game.add.sprite(200,40000,"char");
        player.scale.x = 0.5;
        player.scale.y = 0.5;

        platform = game.add.group();
        platform.enableBody = true;
            for(x=0;x<200;x++){
                if((x%4)==0){
                platforms = platform.create(Math.random()*h/2,50*x,"platform");
                platforms.body.immovable = true;
                platforms.body.collideWorldBounds = true;
                }
            }
        platformTrans = game.add.group();
        platformTrans.enableBody = true;
            for(x=0;x<200;x++){
                if((x%4)==0){
                platformTranss = platformTrans.create(Math.random()*h/2,50*x,"platformTrans");
                platformTranss.body.immovable = true;
                platformTranss.body.collideWorldBounds = true;
                }
            }
        platform2 = game.add.sprite(w/2-15,h/2,"platform2");
        platform2.scale.x = 1.1;
        game.physics.arcade.enable(platform2);
        platform2.body.immovable = true;
        
        enemy = game.add.group();
        enemy.enableBody = true;
        enemy.collideWorldBounds = true;
            for(x=0;x<200;x++){
                if((x%4)==0){
                    enemies = enemy.create(Math.random()*h/1,x*50,"enemy");
                    game.physics.arcade.moveToXY(enemies, Math.round(enemies.body.position.x),Math.round(enemies.body.position.y),200);
                    enemies.body.immovable = true;
                    enemies.body.collideWorldBounds = true;
                    enemies.scale.x =0.6;
                    enemies.scale.y =0.6;
                 
                     var tween = game.add.tween(enemies).to({x:100},1000,Phaser.Easing.Linear.None,true,2000,100,true);
                }
            }
        player.animations.add('walk-right',[1,2,3,4],10,true);
        player.animations.add('walk-left',[6,7,8,9],10,true);
        player.animations.add('up',[16,17,18,19],10,true);
        player.animations.add('down',[11,12,13,14],10,true);

        game.camera.follow(player,Phaser.Camera.FOLLOW_TOPDOWN);

        keyboard = game.input.keyboard.createCursorKeys();

        game.physics.enable(player,Phaser.Physics.ARCADE);
        player.body.collideWorldBounds = true;

        bgAudio = game.add.audio("bgMusic");
        bgAudio.play();
        bgAudio.loop = true;
        bgAudio.play();
      
        makalagpas = game.add.audio("iMadeIt");
        nahuli = game.add.audio("huliKa");
        
		scoreTxt = game.add.text(5,5,"Score: 0", {font:'24px Ar Christy', stroke: 'skyblue',strokeThickness:4});
        scoreTxt.fixedToCamera = true;
		gameOverTxt = game.add.text(50,250,"",{font:'24px Ar Christy', stroke: 'skyblue',strokeThickness:4});
        gameOverTxt.fixedToCamera = true;
        pauseTxt = game.add.text(50,250,"",{font:'24px Ar Christy', stroke: 'skyblue',strokeThickness:4});
        pauseTxt.fixedToCamera = true;
        bestTxt = game.add.text(5,40, "Best: " + process.getData(), {font:'24px Ar Christy', stroke: 'pink',strokeThickness:4});
    	pauseButton = game.add.button(290,0, 'pause',process.pause, this,1,0);
    	pauseButton.scale.x = 0.3;
    	pauseButton.scale.y = 0.3;
    	restartButton = game.add.button(230,0, 'restart',process.restart, this,1,0);
    	restartButton.scale.x = 0.3;
    	restartButton.scale.y = 0.3;
    	pauseButton.fixedToCamera = true; 
        restartButton.fixedToCamera = true;
        
        star1 = game.add.tileSprite(0,
            game.height - game.cache.getImage("star1").height,
            400,
            bounds,
            'star1');
        star2 = game.add.tileSprite(0,
            game.height - game.cache.getImage("star2").height,
            400,
            bounds,
            'star2');
        star3 = game.add.tileSprite(0,
            game.height - game.cache.getImage("star3").height,
            400,
            bounds,
            'star3');
        star4 = game.add.tileSprite(0,
            game.height - game.cache.getImage("star4").height,
            400,
            bounds,
            'star4');
        star5 = game.add.tileSprite(0,
            game.height - game.cache.getImage("star5").height,
            400,
            bounds,
            'star5');
        star6 = game.add.tileSprite(0,
            game.height - game.cache.getImage("star6").height,
            400,
            bounds,
            'star6');

    	buttonbottomleft = game.add.button(5,550, 'left', null, this, 6, 4, 6, 4);
        buttonbottomleft.scale.x = 0.3;
        buttonbottomleft.scale.y = 0.3;
        buttonbottomleft.fixedToCamera = true;
        buttonbottomleft.events.onInputOver.add(function(){left=true;up=true;});
        buttonbottomleft.events.onInputOut.add(function(){left=false;up=false;});
        buttonbottomleft.events.onInputDown.add(function(){left=true;up=true;});
        buttonbottomleft.events.onInputUp.add(function(){left=false;up=false;});

        buttonright = game.add.button(85, 550, 'right', null, this, 0, 1, 0, 1);
        buttonright.scale.x = 0.3;
        buttonright.scale.y = 0.3;
        buttonright.fixedToCamera = true;
        buttonright.events.onInputOver.add(function(){right=true;});
        buttonright.events.onInputOut.add(function(){right=false;});
        buttonright.events.onInputDown.add(function(){right=true;});
        buttonright.events.onInputUp.add(function(){right=false;});

        buttonup = game.add.button(50, 510, 'up', null, this, 0, 1, 0, 1);
        buttonup.scale.x = 0.3;
        buttonup.scale.y = 0.3;
        buttonup.fixedToCamera = true;
        buttonup.events.onInputOver.add(function(){up=true;});
        buttonup.events.onInputOut.add(function(){up=false;});
        buttonup.events.onInputDown.add(function(){up=true;});
        buttonup.events.onInputUp.add(function(){up=false;});
    	
    },
    update: function() {
        game.physics.arcade.overlap(player,platformTrans,process.Makalagpas);
    	game.physics.arcade.collide(enemy,platforms);
    	game.physics.arcade.overlap(player,enemy,process.Nahuli);
         
        player.body.velocity.x = 0;
        player.body.velocity.y = 0;
    	
    	if (left) {
            player.body.velocity.x = -200;
            player.animations.play('walk-left');
        }
        else if (right) {
            player.body.velocity.x =200;
            player.animations.play('walk-right');
        } 
        else if (up) {
            player.body.velocity.y = -200;
            player.animations.play('up');
            star1.tilePosition.y +=0.9
		  star2.tilePosition.y += 2
		  star3.tilePosition.y += 1
		  star4.tilePosition.y += 4
		  star5.tilePosition.y += 3
		  star6.tilePosition.y += 2.8
        }
    }
}
game.state.add("Game", Game, false);